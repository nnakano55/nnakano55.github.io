
// creates the tooltip box
function create_tooltip()
{
	var container = tooltip.append("g");
}

// iterates through zone array and display the information in the zone 
function change_info_year(zone_array)
{
	
}

function change_info_year(prefec_array)
{
	
	
}
